from django.http import HttpResponse, HttpResponseNotFound
from django.shortcuts import render
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist, ValidationError

from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.views import APIView
from rest_framework import viewsets, permissions, exceptions, status

import time
import json
import datetime
from datetime import timedelta
from urllib.parse import urlparse

import requests
from serpapi.google_search_results import GoogleSearchResults

import psycopg2
from sqlalchemy import create_engine
from sqlalchemy import Column, String, Integer, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from apscheduler.schedulers.background import BackgroundScheduler

import boto3
import botocore.exceptions
import hmac
import hashlib
import base64
import json
import uuid
from .models import keywords, results, orgs, members, users, domains
from .serializers import KeywordsSerializer, ResultsSerializer
from .decorators import acc_required
from django.conf import settings
import sys
import re

class ResultsInsert(APIView):

    def post(self):

        try:
            keywords_table = keywords.objects.values_list('id', 'keyword')
            # giving parameters for serpapi and fetching data
            for x in keywords_table:
                is_data_already_existed = results.objects.filter(
                    date=datetime.datetime.today().strftime('%Y-%m-%d'), keyword_id=x[0]).exists()
                if(is_data_already_existed):
                    print('duplicate:', x[1])
                else:
                    try:
                        print('original:', x[1])
                        params = {
                            "q": x[1],
                            "location": "Austin, Texas, United States",
                            "hl": "en",
                            "gl": "us",
                            "num": "30",
                            "google_domain": "google.com",
                            "api_key": "dceb0f8db16278b8c0e3dcbede6e83978e58404cbbde4b3b319edea81d764249"
                        }
                        client = GoogleSearchResults(params)
                        # serpapi result data of keyword
                        results_serp = client.get_dict()
                        print('keyword_Status:',
                              results_serp['search_metadata']['status'])
                        print('organic_results',
                              results_serp['organic_results'])
                        # converting results data from python to json
                        converted_json = json.dumps(results_serp)
                        # getting date and time(unix timestamp)
                        created_time = results_serp['search_metadata']['created_at']
                        json_created_time = created_time.split()
                        extracted_time = json_created_time[0] + \
                            ' ' + json_created_time[1]
                        to_datetime_datatype = datetime.datetime.strptime(
                            extracted_time, '%Y-%m-%d %H:%M:%S')
                        inseconds = time.mktime(
                            to_datetime_datatype.timetuple())
                        in_normal = datetime.datetime.fromtimestamp(inseconds)
                        # return HttpResponse(results['search_metadata']['created_at'])

                        def getHostName(url):
                            parsed_uri = urlparse(url)
                            #result = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
                            result = '{uri.netloc}'.format(uri=parsed_uri)
                            return result
                        # dataframe = list()
                        dataframe = []
                        # appending organic results into dataframe
                        for row in results_serp['organic_results']:
                            data = (row['link'], getHostName(
                                row['link']), row['position'], json_created_time[0], inseconds, x[0])
                            dataframe.append(data)
                        # print(results['organic_results'])
                        # inserting data into results table
                        # flag = flag + 1
                        db_string = settings.DB_STRING
                        db = create_engine(db_string)
                        base = declarative_base()

                        class Results(base):
                            __tablename__ = 'hhh1_results'
                            id = Column(Integer, primary_key=True,
                                        autoincrement=True)
                            url = Column(String)
                            position = Column(Integer)
                            domain = Column(String)
                            date = Column(Date)
                            time = Column(Integer)
                            keyword_id = Column(Integer)

                        Session = sessionmaker(db)
                        session = Session()

                        base.metadata.create_all(db)
                        dicts = []
                        for i in range(len(dataframe)):
                            dicts.append(dict(url=dataframe[i][0], domain=dataframe[i][1], position=dataframe[i]
                                              [2], date=dataframe[i][3], time=dataframe[i][4], keyword_id=dataframe[i][5]))
                        print('dicts:',dicts)
                        session.bulk_insert_mappings(Results, dicts)
                        session.commit()
                    except Exception as e:
                        print("----------------------")
                        print(str(e))
                        print(
                            "Error line:may be no results for the keyword", x[1])
                        print(sys.exc_info()[-1].tb_lineno)
            print("Serp API data successfully Inserted into the results table",
                  datetime.datetime.utcnow())
            return Response('result insert success', status=status.HTTP_200_OK)
        except Exception as e:
            print("----------------------")
            print("error", str(e))
            print("Error at line number", sys.exc_info()[-1].tb_lineno)


class Results(APIView):
    authentication_classes = (acc_required,)

    def get(self, request):
        keyword_id = self.request.query_params.get('id')
        days = self.request.query_params.get('days')
        if days:
            queryset = results.objects.filter(date__gte=(datetime.datetime.now(
            )-timedelta(days=int(days)-1)), keyword_id=keyword_id).order_by('id').values()
        else:
            queryset = results.objects.filter(date__gte=(datetime.datetime.now(
            )-timedelta(days=4)), keyword_id=keyword_id).order_by('id').values()
        duplicate_keys = []
        new_query_set = []
        for query in queryset:
            if str(query['position'])+str(query['date']) not in duplicate_keys:
                new_query_set.append(query)
            duplicate_keys.append(str(query['position'])+str(query['date']))
        return Response(new_query_set)


class Keyword(APIView):
    authentication_classes = (acc_required,)
    def get(self, request, keyword_id=None):

        # user_email=request.META.get('HTTP_EMAIL')
        user_email = self.request.user
        if user_email is None:
            content = {'detail': 'email is not provided'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        if users.objects.filter(email=user_email).exists():
            pass
        else:
            content = {'detail': 'Invalid email'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        if keyword_id:
            user_id_val = users.objects.filter(
                email=user_email).values_list('id')[0][0]
            org_val = members.objects.filter(
                user_id=user_id_val).values_list('org_id')[0][0]
            key_val = keywords.objects.filter(
                id=keyword_id, org_id=org_val).values('id', 'keyword')
            return Response(key_val, status=status.HTTP_200_OK)
        else:
            orgs_list1 = list()
            id_val = users.objects.filter(email=user_email).values('id')
            list1 = list()
            for row in id_val:
                list1.append(row['id'])
            org_id_val = members.objects.filter(
                user_id__in=list1).values('org_id')
            list2 = list()
            for row in org_id_val:
                list2.append(row['org_id'])
            key_val = keywords.objects.filter(
                org_id__in=list2).values('id', 'keyword')
            return Response(key_val, status=status.HTTP_200_OK)

    def post(self, request, keyword_id=None):

        if keyword_id:
            content = {'detail': 'method post not allowed'}
            return Response(content, status=status.HTTP_405_METHOD_NOT_ALLOWED)
        # user_email=request.META.get('HTTP_EMAIL')
        user_email = self.request.user
        try:
            request_data = json.loads(request.body.decode('utf-8'))
        except Exception as e:
            content = {'error': 'must provide a keyword'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        if user_email is None:
            content = {'detail': 'email is not provided'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        # if users.objects.filter(email=user_email).exists():
        #     pass
        # else:
        #     content={'detail':'Invalid email'}
        #     return Response(content,status=status.HTTP_400_BAD_REQUEST)
        try:
            if request_data["keyword"]:
                pass
        except Exception as e:
            content = {'error': str(e)+'is not provided'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        if request_data["keyword"] == '':
            content = {'message': 'keyword cannot be empty'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        else:
            email = user_email
            full_domain = email.split('@')[1]
            domain = full_domain.split('.')[0]
            if domain == 'gmail':
                domain = ''
            try:
                users.objects.create(email=user_email)
                orgs.objects.create(org_name=domain)
                user_id_val = users.objects.filter(
                    email=user_email).values_list('id')[0][0]
                org_val = orgs.objects.values_list('id').order_by("-id")[0][0]
                members.objects.create(
                    admin=True, billing=False, org_id=org_val, user_id=user_id_val)
            except Exception as e:
                user_id_val = users.objects.filter(
                    email=user_email).values_list('id')[0][0]
                org_val = members.objects.filter(
                    user_id=user_id_val).values_list('org_id')[0][0]
            try:
                if keywords.objects.filter(keyword__iexact=request_data["keyword"], org_id=org_val).exists():
                    content = {
                        'message': 'You have given already existed keyword'}
                    return Response(content, status=status.HTTP_400_BAD_REQUEST)
                keywords.objects.create(
                    keyword=request_data["keyword"], org_id=org_val)
                latest_keyword = keywords.objects.filter(
                    keyword=request_data["keyword"], org_id=org_val).values('id', 'keyword')
            except Exception as e:
                content = {'error': str(e)}
                return Response(content, status=status.HTTP_400_BAD_REQUEST)
            try:
                latest_keywords_id = keywords.objects.values_list(
                    'id', 'keyword').order_by("-id")[0][0]
                params = {
                    "q": request_data["keyword"],
                    "location": "Austin, Texas, United States",
                    "hl": "en",
                    "gl": "us",
                    "num": "30",
                    "google_domain": "google.com",
                    "api_key": "dceb0f8db16278b8c0e3dcbede6e83978e58404cbbde4b3b319edea81d764249"
                }
                client = GoogleSearchResults(params)
                # serpapi result data of keyword
                results = client.get_dict()
                # converting results data from python to json
                converted_json = json.dumps(results)
                # getting date and time(unix timestamp)
                created_time = results['search_metadata']['created_at']
                json_created_time = created_time.split()
                extracted_time = json_created_time[0] + \
                    ' ' + json_created_time[1]
                to_datetime_datatype = datetime.datetime.strptime(
                    extracted_time, '%Y-%m-%d %H:%M:%S')
                inseconds = time.mktime(to_datetime_datatype.timetuple())
                in_normal = datetime.datetime.fromtimestamp(inseconds)
                # return HttpResponse(results['search_metadata']['created_at'])

                def getHostName(url):
                    parsed_uri = urlparse(url)
                    #result = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
                    result = '{uri.netloc}'.format(uri=parsed_uri)
                    return result
                dataframe = []
                # appending organic results into dataframe
                for row in results['organic_results']:
                    data = (row['link'], getHostName(row['link']), row['position'], json_created_time[0], inseconds,
                            latest_keywords_id)
                    dataframe.append(data)
                # inserting data into results table
                # db_string = "postgres://postgres:Rahamthulla@db1.coumoo07cfhq.ap-south-1.rds.amazonaws.com"
                db_string = settings.DB_STRING
                db = create_engine(db_string)
                base = declarative_base()

                class Results(base):
                    __tablename__ = 'hhh1_results'
                    id = Column(Integer, primary_key=True, autoincrement=True)
                    url = Column(String)
                    position = Column(Integer)
                    domain = Column(String)
                    date = Column(Date)
                    time = Column(Integer)
                    keyword_id = Column(Integer)

                Session = sessionmaker(db)
                session = Session()

                base.metadata.create_all(db)
                dicts = []
                for i in range(len(dataframe)):
                    dicts.append(dict(url=dataframe[i][0], domain=dataframe[i][1], position=dataframe[i]
                                      [2], date=dataframe[i][3], time=dataframe[i][4], keyword_id=dataframe[i][5]))
                session.bulk_insert_mappings(Results, dicts)
                session.commit()
                content = {'message': 'Your keyword is inserted successfully'}
            except Exception as e:
                content = {'error': str(e)}
                return Response(content, status=status.HTTP_400_BAD_REQUEST)
        return Response(latest_keyword, status=status.HTTP_201_CREATED)

    def delete(self, request, keyword_id=None):

        # user_email=request.META.get('HTTP_EMAIL')
        user_email = self.request.user
        if user_email is None:
            content = {'detail': 'email is not provided'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        if users.objects.filter(email=user_email).exists():
            pass
        else:
            content = {'detail': 'Invalid email'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        if keyword_id:
            user_id_val = users.objects.filter(
                email=user_email).values_list('id')[0][0]
            org_val = members.objects.filter(
                user_id=user_id_val).values_list('org_id')[0][0]
            key_val = keywords.objects.filter(id=keyword_id, org_id=org_val)
            if key_val.count() == 1:
                key_val.delete()
                content = {'detail': 'keyword is deleted'}
                return Response(content, status=status.HTTP_204_NO_CONTENT)
            else:
                content = {
                    'detail': 'You don\'t have any keywords with {} id'.format(keyword_id)}
                return Response(content, status=status.HTTP_400_BAD_REQUEST)
        else:
            # orgs_list1 = list()
            # id_val=users.objects.filter(email=user_email).values('id')
            # list1 = list()
            # for row in id_val:
            #     list1.append(row['id'])
            # org_id_val=members.objects.filter(user_id__in=list1).values('org_id')
            # list2 = list()
            # for row in org_id_val:
            #     list2.append(row['org_id'])
            # key_val=keywords.objects.filter(org_id__in=list2).values('id','keyword')
            # return Response(key_val,status=status.HTTP_200_OK)
            content = {'detail': 'keyword id is not provided'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)


class Domains(APIView):

    authentication_classes = (acc_required,)

    def get(self, request, domain_id=None):
        user_email = self.request.user
        try:
            user_id = users.objects.filter(email=user_email).values_list('id')[0][0]
            if(domain_id):
                domain_name = domains.objects.filter(id=domain_id,user_id=user_id).values('id', 'domain_name')
                return Response(domain_name, status=status.HTTP_200_OK)
            domain_name = domains.objects.filter(user_id=user_id).values('id', 'domain_name')
            return Response(domain_name, status=status.HTTP_200_OK)
        except Exception as e:
            print("Error at line number", sys.exc_info()[-1].tb_lineno)
            content = {'detail': str(e)}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, domain_id=None):
        user_email = self.request.user
        try:
            request_data = json.loads(request.body.decode('utf-8'))
            user_id = users.objects.filter(
                email=user_email).values_list('id')[0][0]
            extracted_domain=request_data['domain_name'].lower().replace('www.','')
            if('https://' in request_data['domain_name'] or 'http://' in request_data['domain_name']):
                extracted_domain=urlparse(request_data['domain_name']).netloc.lower().replace('www.','')
            domain_check=re.search(r'^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$',extracted_domain)
            try:
                if(domain_check.string):
                    final_domain=domain_check.string
                    if domains.objects.filter(domain_name__iexact=final_domain, user_id=user_id).exists():
                        content = {'detail': 'domain already existed'}
                        return Response(content, status=status.HTTP_400_BAD_REQUEST)
                    domains.objects.create(
                        domain_name=final_domain, user_id=user_id)
                    latest_domain=domains.objects.filter(domain_name=final_domain, user_id=user_id).values('id','domain_name')
                    return Response(latest_domain, status=status.HTTP_201_CREATED)
            except Exception as e:
                print("at line number", sys.exc_info()[-1].tb_lineno)
                content = {'detail': 'domain format is incorrect'}
                return Response(content, status=status.HTTP_400_BAD_REQUEST) 
        except Exception as e:
            print("Error at line number", sys.exc_info()[-1].tb_lineno)
            content = {'detail': str(e)}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, domain_id=None):
        user_email = self.request.user
        if domain_id:
            try:
                user_id = users.objects.filter(
                    email=user_email).values_list('id')[0][0]
                is_domain_id_exists = domains.objects.filter(
                    id=domain_id, user_id=user_id)
                if is_domain_id_exists.count() == 1:
                    is_domain_id_exists.delete()
                    content = {'detail': 'domain is deleted'}
                    return Response(content, status=status.HTTP_204_NO_CONTENT)
                else:
                    content = {
                        'detail': 'You don\'t have any domains with {} id'.format(domain_id)}
                    return Response(content, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                print("Error at line number", sys.exc_info()[-1].tb_lineno)
                content = {'detail': str(e)}
                return Response(content, status=status.HTTP_400_BAD_REQUEST)
        else:
            content = {'detail': 'domain id is not provided in url'}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)


class Login(APIView):

    def get(self, request):
        try:
            code = request.META.get('HTTP_CODE')
            # request_data=json.loads(request.body.decode('utf-8'))
            # code=request_data['code']
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            #headers={'Content-Type':'application/x-www-form-urlencoded', 'Authorization':'Basic  MTRuYWphamp0N3ZvbmU3Z2xscmxtNW1kbms6MTdyczI2N2ZucjB1cDducnBiNWI0Z2NzdWk0ZmMybWQ0MmNkZ3A1NWplbG42cDVja3U4Nw=='}
            payload = {'grant_type': 'authorization_code', 'client_id': settings.CLIENT_ID,
                       'client_secret': settings.CLIENT_SECRET, 'code': code, 'redirect_uri': settings.REDIRECT_URI}
            post_data = requests.post('https://'+settings.DOMAIN_PREFIX +
                                      '.auth.us-east-1.amazoncognito.com/oauth2/token', headers=headers,  data=payload)
            client = boto3.client('cognito-idp', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                                  aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY_ID, region_name='us-east-1')
            res = post_data.json()
            response = client.get_user(AccessToken=res['access_token'])
            for i in response['UserAttributes']:
                if(i['Name'] == 'email'):
                    print(i['Value'])
                    content = {'Tokens': res, 'User': i['Value']}
                    return Response(content, status=status.HTTP_200_OK)
        except Exception as e:
            content = {'error': str(
                e), 'line_number': sys.exc_info()[-1].tb_lineno}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:
            request_data = json.loads(request.body.decode('utf-8'))
            USER_POOL_ID = 'us-east-1_yALiHLLjw'
            CLIENT_ID = settings.CLIENT_ID
            CLIENT_SECRET = settings.CLIENT_SECRET
            client = boto3.client('cognito-idp', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                                  aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY_ID, region_name='us-east-1')

            def get_secret_hash(username):
                msg = username + CLIENT_ID
                dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'),
                               msg=str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
                d2 = base64.b64encode(dig).decode()
                return d2

            def initiate_auth(username, password):
                try:
                    resp = client.admin_initiate_auth(
                        UserPoolId=USER_POOL_ID,
                        ClientId=CLIENT_ID,
                        AuthFlow='ADMIN_NO_SRP_AUTH',
                        AuthParameters={
                            'USERNAME': username,
                            'SECRET_HASH': get_secret_hash(username),
                            'PASSWORD': password
                        },
                        ClientMetadata={
                            'username': username,
                            'password': password
                        })
                except client.exceptions.NotAuthorizedException as e:
                    return None, "The username or password is incorrect"
                except Exception as e:
                    print(e)
                    return None, "Unknown error"
                return resp, None
            resp, msg = initiate_auth(
                request_data['username'], request_data['password'])
            access_token = resp['AuthenticationResult']['AccessToken']
            content = {'Access_Token': access_token}
            return Response(content, status=status.HTTP_200_OK)
        except Exception as e:
            content = {'error': str(
                e), 'line_number': sys.exc_info()[-1].tb_lineno}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)


# Test API view of Keywordsview for all operations Like POST,GET,PUT,DELETE
class TestKeywords(viewsets.ModelViewSet):
    # authentication_classes=(acc_required,)
    queryset = keywords.objects.all()
    serializer_class = KeywordsSerializer


class Users(APIView):

    def get(self, request, org_name):
        orgs_data = orgs.objects.filter(org_name__iexact=org_name).values()
        s_val = orgs_data[0]['id']
        org_val = members.objects.filter(org_id=s_val)
        queryset = User.objects.filter(id__in=org_val).values('username')
        return Response(queryset)


class Orgs(APIView):
    def get(self, request, user_name):
        queryset = User.objects.filter(username=user_name).values()
        s_val = queryset[0]['id']
        org_val = members.objects.filter(user_id=s_val).values('org_id')
        list1 = list()
        for row in org_val:
            list1.append(row['org_id_id'])
        orgs_data = orgs.objects.filter(id__in=list1).values('org_name')
        return Response(orgs_data)
