from django.apps import AppConfig


class Hhh1Config(AppConfig):
    name = 'hhh1'
    def ready(self):
        from hhh1 import updater
        updater.start()
