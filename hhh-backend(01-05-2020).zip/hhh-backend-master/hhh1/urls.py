
from django.urls import path, include
from . import views
from rest_framework import routers

router = routers.DefaultRouter()


router.register('test-keywords', views.TestKeywords)
from django.contrib.auth import views as auth_views
urlpatterns = [

path('v1/',include([
    path('', include(router.urls)),
    path('results', views.Results.as_view(), name='user_results'),
    path('keywords', views.Keyword.as_view(), name='user_keywords'),
    path('keywords/<int:keyword_id>', views.Keyword.as_view(), name='user_keywords'),
    path('login', views.Login.as_view(), name='login'),
    path('domains', views.Domains.as_view(), name='domains'),
    path('domains/<int:domain_id>', views.Domains.as_view(), name='domains'),
    ]))

]


      #path('1.0/signup', views.SignUpView.as_view(), name='signUp'),
      #path('1.0/orgs/<org_name>', views.Users.as_view(), name='orgs'),
      #path('1.0/users/<user_name>', views.Orgs.as_view(), name='users'),

      #path('1.0/postkeyword', views.PostKeyword.as_view(), name='PostKeyword'),










# router.register('primarykeywords', views.PrimaryKeywordsview)
# from django.contrib.auth import views as auth_views
# urlpatterns = [
#       path('', include(router.urls)),
#       path('login/', views.LoginView.as_view(), name='login'),
#       path('signup/', views.SignUpView.as_view(), name='signUp'),
#       path('orgs/<org_name>/', views.Usersview.as_view(), name='orgs'),
#       path('users/<user_name>/', views.Orgsview.as_view(), name='users'),
#       path('results', views.Resultsview.as_view(), name='results'),
#       path('keywords', views.Keywordsview.as_view(), name='keywords'),
#       path('Addkeywords/', views.AddkeywordsView.as_view(), name='AddKeyword'),
#
# ]
