from rest_framework import serializers
from .models import keywords
from .models import results
from django.contrib.auth.models import User

class KeywordsSerializer(serializers.ModelSerializer):
    class Meta:
        model = keywords
        fields = '__all__'

class ResultsSerializer(serializers.ModelSerializer):
    class Meta:
        model = results
        #fields = ('domain')
        fields = '__all__'

# class UsersSerializer(serializers.HyperlinkedModelSerializer):
#     orgs_associated = serializers.HyperlinkedIdentityField(view_name='hhh1:results-detail')
#     class Meta:
#         model = User
#         fields = ('username','orgs_associated')
