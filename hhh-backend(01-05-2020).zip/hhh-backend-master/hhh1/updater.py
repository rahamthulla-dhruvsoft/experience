from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from . import views

def start():
    scheduler = BackgroundScheduler()
    scheduler.add_job(views.ResultsInsert().post, 'cron', month= '1-12', day = '1-31', hour= '4', minute='0', second='0')
    print("Scheduler started",datetime.now())
    scheduler.start()
