from django.test import TestCase


# from django.views.decorators.csrf import csrf_exempt
# import stripe
# stripe.api_key = 'sk_test_9USOBTyMN7s0s175qLjztFfH00qhwipd0P'
#
# import json
# from django.http import HttpResponse
#
# # Using Django
# @csrf_exempt
# def my_webhook_view(request):
#   payload = request.body
#   print(payload)
#   event = None
#
#   try:
#     event = stripe.Event.construct_from(
#       json.loads(payload), stripe.api_key
#     )
#   except ValueError as e:
#     # Invalid payload
#     return HttpResponse(status=400)
#
#   # Handle the event
#   if event.type == 'payment_intent.succeeded':
#     payment_intent = event.data.object # contains a stripe.PaymentIntent
#     print('PaymentIntent was successful!')
#   elif event.type == 'payment_method.attached':
#     payment_method = event.data.object # contains a stripe.PaymentMethod
#     print('PaymentMethod was attached to a Customer!')
#   # ... handle other event types
#   else:
#     # Unexpected event type
#     return HttpResponse(status=400)
#
#   return HttpResponse(status=200)









#1.ccreate a user table
#2.check the user[org] have same keyword or not

# # Create your tests here.

# import jwt
# #jwt.decode(<encoded token>,<secret key>,<algorthm>)
# decodedPayload = jwt.decode('eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNTc4NDcwMDU5LCJqdGkiOiIzNWZiMmMwYzUzNDA0ZjFhOTgyNzA2N2U5MGU3OWIwZCIsInVzZXJfaWQiOjh9.HfQUxzhweKDyvdnEmM8VomnVaMR0j4qTt7VwruxCpyo',None,None)
# print(decodedPayload['exp'])
# from django.core.mail import send_mail
# send_mail('Subject here','Here is the message.','from@example.com',['rahamthulla@dhruvsoft.com'],fail_silently=False,)

# from django.contrib.auth.models import User
# if User.objects.filter(username='abc@xyz.com').exists():
#     print('exists')
# else:
#     print('Not exists')


# class Orgsview(viewsets.ModelViewSet):
#         queryset = User.objects.all()
#         serializer_class = UsersSerializer
# class ResultsView(viewsets.ModelViewSet):
#         queryset = resultsModel.objects.filter(date__gte=(datetime.datetime.now()-timedelta(days = 7)),keyword_id_id=1)
#         serializer_class = ResultsSerializer
# class KeywordsView(viewsets.ModelViewSet):
#     queryset = keywords.objects.all()
#     serializer_class = KeywordsSerializer

# cursor = connection.cursor()
# cursor.execute("select keyword from hhh1_keywords where org_id_id IN(select org_id_id from hhh1_members where user_id_id IN (select id from auth_user where username='"+username+"'))")
# for row in cursor.fetchall():
#     orgs_list1.append(row[0])


    # user = authenticate(username=request_data["username"], password=request_data["password"])
    # if user is not None:
    #     print('Authenticated user')
    #     content = {'message': 'Authenticated user','keywords':key_val}
    #     return Response(content)
    # else:
    #     print('Not Authenticated user')
    #     return Response(status=status.HTTP_401_UNAUTHORIZED)


#=================
#print(ghd())
# print(response['UserAttributes'][4]['Name'])
# for i in response['UserAttributes']:
#     if(i['Name']=='email'):
#         print(i['Value'])
# response = client.admin_get_user(
#     UserPoolId='ap-south-1_7argqFlMb',
#     Username='69d7705d-16a4-40ef-adc6-177f16d4b184'
# )
# print(response)



#from __future__ import print_function
# import boto3
# import botocore.exceptions
# import hmac
# import hashlib
# import base64
# import json
# import uuid
#
# # MODIFY
# USER_POOL_ID = 'ap-south-1_7argqFlMb'
# CLIENT_ID = '32one45v2veuktibghj2c56q4'
# CLIENT_SECRET = '1fh086t2lk65d0a7u8pdsjl3l23f5oq9gsbjurhcnshi2mnuripc'
# client = boto3.client('cognito-idp')
#
#
# def get_secret_hash(username):
#     msg = username + CLIENT_ID
#     dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'),
#         msg = str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
#     d2 = base64.b64encode(dig).decode()
#     return d2
#
# def initiate_auth(username, password):
#     try:
#         resp = client.admin_initiate_auth(
#             UserPoolId=USER_POOL_ID,
#             ClientId=CLIENT_ID,
#             AuthFlow='ADMIN_NO_SRP_AUTH',
#             AuthParameters={
#                 'USERNAME': username,
#                 'SECRET_HASH': get_secret_hash(username),
#                 'PASSWORD': password
#             },
#             ClientMetadata={
#                 'username': username,
#                 'password': password
#             })
#     except client.exceptions.NotAuthorizedException as e:
#         return None, "The username or password is incorrect"
#     except Exception as e:
#         print(e)
#         return None, "Unknown error"
#     return resp, None
#
# resp, msg = initiate_auth('rahamthulla@dhruvsoft.com', 'Blackhole@pi1')
# id_token = resp['AuthenticationResult']['IdToken']
# access_token = resp['AuthenticationResult']['AccessToken']
# expires_in = resp['AuthenticationResult']['ExpiresIn']
# refresh_token = resp['AuthenticationResult']['RefreshToken']
# print(str(resp))
# print('id token: ' + id_token)
# print('access_token: ' + access_token)
# print('expires_in: ' + str(expires_in))
# print('refresh_token: ' + refresh_token)

# import boto3
# client = boto3.client('cognito-idp')
# response = client.set_ui_customization(
#     UserPoolId='ap-south-1_7argqFlMb',
#     ClientId='3lq4vhu1mkirqd46sacrkigd9a',
#     CSS='.logo-customizable {\n\tmax-width: 100%;\n\tmax-height: 30%;\n}\n.banner-customizable {\n\tpadding: 25px 0px 25px 10px;\n\tbackground-color: lightgray;\n}\n.label-customizable {\n\tfont-weight: 300;\n}\n.textDescription-customizable {\n\tpadding-top: 10px;\n\tpadding-bottom: 10px;\n\tdisplay: block;\n\tfont-size: 16px;\n}\n.idpDescription-customizable {\n\tpadding-top: 10px;\n\tpadding-bottom: 10px;\n\tdisplay: block;\n\tfont-size: 16px;\n}\n.legalText-customizable {\n\tcolor: #747474;\n\tfont-size: 11px;\n}\n.submitButton-customizable {\n\tfont-size: 14px;\n\tfont-weight: bold;\n\tmargin: 20px 0px 10px 0px;\n\theight: 40px;\n\twidth: 100%;\n\tcolor: #fff;\n\tbackground-color: #337ab7;\n}\n.submitButton-customizable:hover {\n\tcolor: #fff;\n\tbackground-color: #286090;\n}\n.errorMessage-customizable {\n\tpadding: 5px;\n\tfont-size: 14px;\n\twidth: 100%;\n\tbackground: #F5F5F5;\n\tborder: 2px solid #D64958;\n\tcolor: #D64958;\n}\n.inputField-customizable {\n\twidth: 100%;\n\theight: 34px;\n\tcolor: #555;\n\tbackground-color: #fff;\n\tborder: 1px solid #ccc;\n}\n.inputField-customizable:focus {\n\tborder-color: #66afe9;\n\toutline: 0;\n}\n.idpButton-customizable {\n\theight: 40px;\n\twidth: 100%;\n\ttext-align: center;\n\tmargin-bottom: 15px;\n\tcolor: #fff;\n\tbackground-color: #5bc0de;\n\tborder-color: #46b8da;\n}\n.idpButton-customizable:hover {\n\tcolor: #fff;\n\tbackground-color: #31b0d5;\n}\n.socialButton-customizable {\n\theight: 40px;\n\ttext-align: left;\n\twidth: 100%;\n\tmargin-bottom: 15px;\n}\n.redirect-customizable {\n\ttext-align: center;\n}\n.passwordCheck-notValid-customizable {\n\tcolor: #DF3312;\n}\n.passwordCheck-valid-customizable {\n\tcolor: #19BF00;\n}\n.background-customizable {\n\tbackground-color: #faf;\n}\n',
#     #ImageFile=b'bytes'
#     #"ImageUrl": "https://www.google.com/search?q=hello&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiC29WHxb_nAhW6zDgGHSIFDQwQ_AUoBHoECBEQBg&biw=1600&bih=740#imgrc=teqP5ptslqk2yM"
# )

#========================
#
# from django.utils.translation import gettext_lazy as _
# from rest_framework import HTTP_HEADER_ENCODING, authentication
#
# from .exceptions import AuthenticationFailed, InvalidToken, TokenError
# from .models import TokenUser
# from .settings import api_settings
# from .state import User
#
# AUTH_HEADER_TYPES = api_settings.AUTH_HEADER_TYPES
#
# if not isinstance(api_settings.AUTH_HEADER_TYPES, (list, tuple)):
#     AUTH_HEADER_TYPES = (AUTH_HEADER_TYPES,)
#
# AUTH_HEADER_TYPE_BYTES = set(
#     h.encode(HTTP_HEADER_ENCODING)
#     for h in AUTH_HEADER_TYPES
# )
#
#
# class JWTAuthentication(authentication.BaseAuthentication):
#     """
#     An authentication plugin that authenticates requests through a JSON web
#     token provided in a request header.
#     """
#     www_authenticate_realm = 'api'
#
#     def authenticate(self, request):
#         header = self.get_header(request)
#         if header is None:
#             return None
#
#         raw_token = self.get_raw_token(header)
#         if raw_token is None:
#             return None
#
#         validated_token = self.get_validated_token(raw_token)
#
#         return self.get_user(validated_token), validated_token
#
#     def authenticate_header(self, request):
#         return '{0} realm="{1}"'.format(
#             AUTH_HEADER_TYPES[0],
#             self.www_authenticate_realm,
#         )
#
#     def get_header(self, request):
#         """
#         Extracts the header containing the JSON web token from the given
#         request.
#         """
#         header = request.META.get('HTTP_AUTHORIZATION')
#
#         if isinstance(header, str):
#             # Work around django test client oddness
#             header = header.encode(HTTP_HEADER_ENCODING)
#
#         return header
#
#     def get_raw_token(self, header):
#         """
#         Extracts an unvalidated JSON web token from the given "Authorization"
#         header value.
#         """
#         parts = header.split()
#
#         if len(parts) == 0:
#             # Empty AUTHORIZATION header sent
#             return None
#
#         if parts[0] not in AUTH_HEADER_TYPE_BYTES:
#             # Assume the header does not contain a JSON web token
#             return None
#
#         if len(parts) != 2:
#             raise AuthenticationFailed(
#                 _('Authorization header must contain two space-delimited values'),
#                 code='bad_authorization_header',
#             )
#
#         return parts[1]
#
#     def get_validated_token(self, raw_token):
#         """
#         Validates an encoded JSON web token and returns a validated token
#         wrapper object.
#         """
#         messages = []
#         for AuthToken in api_settings.AUTH_TOKEN_CLASSES:
#             try:
#                 return AuthToken(raw_token)
#             except TokenError as e:
#                 messages.append({'token_class': AuthToken.__name__,
#                                  'token_type': AuthToken.token_type,
#                                  'message': e.args[0]})
#
#         raise InvalidToken({
#             'detail': _('Given token not valid for any token type'),
#             'messages': messages,
#         })
#
#     def get_user(self, validated_token):
#         """
#         Attempts to find and return a user using the given validated token.
#         """
#         try:
#             user_id = validated_token[api_settings.USER_ID_CLAIM]
#         except KeyError:
#             raise InvalidToken(_('Token contained no recognizable user identification'))
#
#         try:
#             user = User.objects.get(**{api_settings.USER_ID_FIELD: user_id})
#         except User.DoesNotExist:
#             raise AuthenticationFailed(_('User not found'), code='user_not_found')
#
#         if not user.is_active:
#             raise AuthenticationFailed(_('User is inactive'), code='user_inactive')
#
#         return user
#
#
# class JWTTokenUserAuthentication(JWTAuthentication):
#     def get_user(self, validated_token):
#         """
#         Returns a stateless user object which is backed by the given validated
#         token.
#         """
#         if api_settings.USER_ID_CLAIM not in validated_token:
#             # The TokenUser class assumes tokens will have a recognizable user
#             # identifier claim.
#             raise InvalidToken(_('Token contained no recognizable user identification'))
#
#         return TokenUser(validated_token)

#===================
# client = boto3.client('cognito-idp', aws_access_key_id='AKIAI27FFNSJRARRYCAQ',aws_secret_access_key='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')
# response = client.list_users(UserPoolId='ap-south-1_7argqFlMb')
# for j in response['Users']:
#     for i in j['Attributes']:
#         if(i['Name']=='email'):
#             try:
#                 users.objects.create(user_name=i['Value'],email=i['Value'])
#             except Exception as e:
#                 print({'error':str(e)})
#===================

    # try:
    #     members.objects.create(admin=False,billing=False,org_id_id=,user_id_id=)
    # list5 = list()
    # for row in id_val:
    #     list5.append(row['id'])
    # #getting org_id from user name
    # org_id_val=members.objects.filter(user_id_id=list5[0]).values('org_id_id')
    # if not org_id_val:
    #     print("not exists")
    # list4 = list()
    # for row in org_id_val:
    #     list4.append(row['org_id_id'])
    #========================


    # class hello(APIView):
    #     #permission_classes = (acc_required,)
    #     def get(self,request):
    #         request_data=json.loads(request.body.decode('utf-8'))
    #         #content = {'Access_token':access_token,'Refresh_token':refresh_token}
    #         return Response(request_data)



    # for row in keywords_table:
    #     keywords_table_id.append(row[0])
    # print(keywords_table_id.pop())
    # a=int(input("Enter a Value"))
    # b=int(input("Enter b Value"))
    # print(a+b)
    # if(a==3 or  b==4):
    #     print("HEllodd")


    # import boto3
    # client = boto3.client('cognito-idp')
    # response = client.set_ui_customization(
    #     UserPoolId='ap-south-1_7argqFlMb',
    #     ClientId='3lq4vhu1mkirqd46sacrkigd9a',
    #     CSS='.logo-customizable {\n\tmax-width: 100%;\n\tmax-height: 30%;\n}\n.banner-customizable {\n\tpadding: 200px 200px 200px 200px;\n\tbackground-color: lightgreen;\n}\n.label-customizable {\n\tfont-weight: 300;\n}\n.textDescription-customizable {\n\tpadding-top: 10px;\n\tpadding-bottom: 10px;\n\tdisplay: block;\n\tfont-size: 16px;\n}\n.idpDescription-customizable {\n\tpadding-top: 10px;\n\tpadding-bottom: 10px;\n\tdisplay: block;\n\tfont-size: 16px;\n}\n.legalText-customizable {\n\tcolor: #747474;\n\tfont-size: 11px;\n}\n.submitButton-customizable {\n\tfont-size: 14px;\n\tfont-weight: bold;\n\tmargin: 20px 0px 10px 0px;\n\theight: 40px;\n\twidth: 100%;\n\tcolor: #fff;\n\tbackground-color: #337ab7;\n}\n.submitButton-customizable:hover {\n\tcolor: #fff;\n\tbackground-color: #286090;\n}\n.errorMessage-customizable {\n\tpadding: 5px;\n\tfont-size: 14px;\n\twidth: 100%;\n\tbackground: #F5F5F5;\n\tborder: 2px solid #D64958;\n\tcolor: #D64958;\n}\n.inputField-customizable {\n\twidth: 100%;\n\theight: 34px;\n\tcolor: #555;\n\tbackground-color: #fff;\n\tborder: 1px solid #ccc;\n}\n.inputField-customizable:focus {\n\tborder-color: #66afe9;\n\toutline: 0;\n}\n.idpButton-customizable {\n\theight: 40px;\n\twidth: 100%;\n\ttext-align: center;\n\tmargin-bottom: 15px;\n\tcolor: #fff;\n\tbackground-color: #5bc0de;\n\tborder-color: #46b8da;\n}\n.idpButton-customizable:hover {\n\tcolor: #fff;\n\tbackground-color: #31b0d5;\n}\n.socialButton-customizable {\n\theight: 40px;\n\ttext-align: left;\n\twidth: 100%;\n\tmargin-bottom: 15px;\n}\n.redirect-customizable {\n\ttext-align: center;\n}\n.passwordCheck-notValid-customizable {\n\tcolor: #DF3312;\n}\n.passwordCheck-valid-customizable {\n\tcolor: #19BF00;\n}\n.background-customizable {\n\tbackground-color: #faf;\n}\n',
    #     #ImageFile=b'bytes'
    #     #"ImageUrl": "https://www.google.com/search?q=hello&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiC29WHxb_nAhW6zDgGHSIFDQwQ_AUoBHoECBEQBg&biw=1600&bih=740#imgrc=teqP5ptslqk2yM"
    # )
    # print("applied")
    import boto3
    client = boto3.client('cognito-idp')
    # response = client.get_user(
    #     AccessToken='eyJraWQiOiI4NDZPenNrN3NjaTNwSkpoXC9QUUNEWmxPQ3lkWE9HcWtua0xlZjRUOTNXbz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxM2UwZTRlMC04NDVmLTQ5ZjItYmMwZC1kNzE5ZGY3N2ZhMzYiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6ImF3cy5jb2duaXRvLnNpZ25pbi51c2VyLmFkbWluIHBob25lIG9wZW5pZCBwcm9maWxlIGVtYWlsIiwiYXV0aF90aW1lIjoxNTgyMDk3MzA4LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAuYXAtc291dGgtMS5hbWF6b25hd3MuY29tXC9hcC1zb3V0aC0xXzdhcmdxRmxNYiIsImV4cCI6MTU4MjEwMDkwOCwiaWF0IjoxNTgyMDk3MzA4LCJ2ZXJzaW9uIjoyLCJqdGkiOiIzOTg4NDk4ZC03Y2QxLTQyYTAtOWNmMC0xYzc0YTA3OGIwYzgiLCJjbGllbnRfaWQiOiIxNG5hamFqanQ3dm9uZTdnbGxybG01bWRuayIsInVzZXJuYW1lIjoiMTNlMGU0ZTAtODQ1Zi00OWYyLWJjMGQtZDcxOWRmNzdmYTM2In0.FNsSGsdWZpG8Nm6rwTeYZFORR4A-IIkApZsGRFkJE2YIQQP3Nv_Lak67_h5AADW08GtMN3zSvhV095gQ4N1DF0aeyjw7R93VIZzwqoSl8kgrN2UGRhUDt41m5x26LHHqz1MvkaZoBcECyvjHsa4Rx55kGa-P0AzUQhV7FvivmGkkcPIEjRNEathMWmN0W-zfNs1hcK9nuVt0Ujc_SMXpllYYKRTp9aOPdJyLw8I2E9gveN6FrfFKlXlc72qsh1VNyctyPgcULyh6bQHo0ZwpEJyt9zaCOm4pAoZV-ceZv5WngS-_H8xkeL0vU6uuvbQxOKnUzOfAMwdvIDblMlgRlg'
    # )
    # response = client.list_users(
    #     UserPoolId='ap-south-1_7argqFlMb',
    #     # AttributesToGet=[
    #     #     'string',
    #     # ],
    #     # Limit=123,
    #     # PaginationToken='string',
    #     #Filter='string'
    # )
    # print(response)


    #
    # import boto3
    # import botocore.exceptions
    # import hmac
    # import hashlib
    # import base64
    # import json
    # import uuid
    #
    # # MODIFY
    # USER_POOL_ID = 'ap-south-1_7argqFlMb'
    # CLIENT_ID = '14najajjt7vone7gllrlm5mdnk'
    # CLIENT_SECRET = '17rs267fnr0up7nrpb5b4gcsui4fc2md42cdgp55jeln6p5cku87'
    # client = boto3.client('cognito-idp')
    #
    #
    # def get_secret_hash(username):
    #     msg = username + CLIENT_ID
    #     dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'),
    #         msg = str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
    #     d2 = base64.b64encode(dig).decode()
    #     return d2
    #
    # def initiate_auth(username, password):
    #     try:
    #         resp = client.admin_initiate_auth(
    #             UserPoolId=USER_POOL_ID,
    #             ClientId=CLIENT_ID,
    #             AuthFlow='ADMIN_NO_SRP_AUTH',
    #             AuthParameters={
    #                 'USERNAME': username,
    #                 'SECRET_HASH': get_secret_hash(username),
    #                 'PASSWORD': password
    #             },
    #             ClientMetadata={
    #                 'username': username,
    #                 'password': password
    #             })
    #     except client.exceptions.NotAuthorizedException as e:
    #         return None, "The username or password is incorrect"
    #     except Exception as e:
    #         print(e)
    #         return None, "Unknown error"
    #     return resp, None
    #
    # resp, msg = initiate_auth('rahamthulla@dhruvsoft.com', 'Blackhole@pi1')
    # #id_token = resp['AuthenticationResult']['IdToken']
    # print(resp)
# container_commands:
#    01_pip_upgrade:
#        command: "/opt/python/run/venv/bin/pip install --upgrade pip"
#        ignoreErrors: false
#    02_makemigrations:
#        command: "source /opt/python/run/venv/bin/activate && python manage.py makemigrations --noinput"
#        leader_only: true
#    03_migrate:
#        command: "source /opt/python/run/venv/bin/activate && python manage.py migrate --noinput"
#        leader_only: true
