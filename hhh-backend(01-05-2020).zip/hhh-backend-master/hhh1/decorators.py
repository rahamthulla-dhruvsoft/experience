from rest_framework import authentication
import boto3
from rest_framework import exceptions
from django.conf import settings
client = boto3.client('cognito-idp',aws_access_key_id=settings.AWS_ACCESS_KEY_ID,aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY_ID,region_name='us-east-1')
#client = boto3.client('cognito-idp',aws_access_key_id='AKIAI27FFNSJRARRYCAQ',aws_secret_access_key='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',region_name='ap-south-1')
class acc_required(authentication.TokenAuthentication):

    def authenticate(self, request):
        print('-----------------------')
        print('META: ',request.META)
        header=request.META.get('HTTP_TOKEN')
        if header is None:
            raise exceptions.AuthenticationFailed('Access token not provided')
        res=self.validate_token(header)
        return res,header
    def validate_token(self,access_token):
        try:
            response = client.get_user(AccessToken=access_token)
        except Exception as e:
            raise exceptions.AuthenticationFailed(e)
        else:
            for i in response['UserAttributes']:
                    if(i['Name']=='email'):
                        content =i['Value']
            return content
    def has_permission(self, request, view, obj=None):
    # Write permissions are only allowed to the owner of the snippet
        return obj is None or obj.from_user == request.user
