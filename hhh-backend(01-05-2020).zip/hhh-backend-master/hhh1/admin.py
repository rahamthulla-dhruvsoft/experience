from django.contrib import admin
from . models import keywords
from . models import results
from . models import orgs
from . models import members , users

admin.site.site_header='HHH Administration'
class ResultsAdmin(admin.ModelAdmin):
    list_display=('domain', 'date')
    list_filter=('date',)
admin.site.register(results,ResultsAdmin)
admin.site.register(keywords)
admin.site.register(orgs)
admin.site.register(members)
admin.site.register(users)
