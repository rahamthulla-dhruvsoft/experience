from django.db import models
from django.contrib.auth.models import User
from django.conf import settings



class users(models.Model):
    email=models.EmailField(max_length=50,unique=True)
    def __str__(self):
        return self.email

class domains(models.Model):
    domain_name=models.CharField(max_length=200,blank=False)
    user=models.ForeignKey(users, on_delete=models.CASCADE)

    def __str__(self):
        return self.domain_name

class orgs(models.Model):
    org_name=models.CharField(max_length=200,blank=True)

    def __str__(self):
        return self.org_name

class keywords(models.Model):
    keyword=models.CharField(max_length=200,blank=False)
    org=models.ForeignKey(orgs, on_delete=models.CASCADE)

    def __str__(self):
        return self.keyword

class results(models.Model):
    url=models.URLField(max_length=1000)
    position=models.IntegerField()
    domain=models.TextField()
    date=models.DateField(auto_now_add=True)
    time=models.IntegerField()
    keyword=models.ForeignKey(keywords, on_delete=models.CASCADE)

    def __str__(self):
        return self.url

class members(models.Model):
    user=models.ForeignKey(users, on_delete=models.CASCADE)
    org=models.ForeignKey(orgs, on_delete=models.CASCADE)
    admin=models.BooleanField()
    billing=models.BooleanField()

    # def __str__(self):
    #     return self.user
